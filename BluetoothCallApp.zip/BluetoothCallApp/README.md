# BluetoothCallApp

Free Bluetooth voice calls and text messages between Android phones. No SIM credit needed.

## Features
- Voice calls over Bluetooth (no cellular network required)
- Text messaging
- Saved device contacts
- Call history
- Works offline

## How to Build the APK (No Android Studio Needed)

### Option A: GitHub Actions (Easiest - No software needed)

1. Go to https://github.com and create a free account
2. Click the **+** button → **New repository**
3. Name it `BluetoothCallApp`
4. Make it **Public**
5. Click **Create repository**
6. On the next page, click **uploading an existing file**
7. Drag and drop ALL the files/folders from this project into the upload area
8. Click **Commit changes**
9. Go to the **Actions** tab at the top
10. Wait 3-5 minutes for the build to complete
11. Click on the completed workflow run
12. Scroll down to **Artifacts** and download `BluetoothCallApp-APK`
13. Extract the ZIP — your `.apk` file is inside!

### Option B: AIDE on Android Phone

1. Install **AIDE** from Google Play Store
2. Extract this project to your phone storage
3. Open AIDE → Open Project → select the BluetoothCallApp folder
4. Tap **Run** — AIDE will compile and install the APK

## How to Use

1. Install the APK on two Android phones (Android 7.0+)
2. Pair the phones in system Bluetooth settings first
3. Open the app on both phones
4. Devices appear in the Devices tab
5. Tap Call or Message

## Bluetooth Range
- Open outdoor: ~50-100 meters
- Indoor with walls: ~10-30 meters
