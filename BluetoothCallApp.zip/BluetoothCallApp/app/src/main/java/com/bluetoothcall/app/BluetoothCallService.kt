package com.bluetoothcall.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class BluetoothCallService : Service() {

    private val binder = LocalBinder()
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var serverSocket: BluetoothServerSocket? = null
    private val clientSockets = ConcurrentHashMap<String, BluetoothSocket>()
    private val outputStreams = ConcurrentHashMap<String, OutputStream>()
    private val inputStreams = ConcurrentHashMap<String, InputStream>()
    private var isRunning = false

    // Audio
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isInCall = false
    private var currentCallDevice: String? = null
    private var callStartTime: Long = 0
    private var isMuted = false
    private var audioManager: AudioManager? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val connectedDevices = mutableSetOf<String>()

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothCallService = this@BluetoothCallService
    }

    override fun onCreate() {
        super.onCreate()
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "BluetoothCall::WakeLock"
        )
        registerReceivers()
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground()
        if (!isRunning) {
            isRunning = true
            startServer()
        }
        return START_STICKY
    }

    private fun startForeground() {
        val channelId = "bluetooth_call_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Bluetooth Call Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Bluetooth Call")
            .setContentText("Listening for connections...")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pendingIntent)
            .build()
        startForeground(1, notification)
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        registerReceiver(bluetoothReceiver, filter)
    }

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    device?.let { AppData.getOrCreateContact(it) }
                }
            }
        }
    }

    private fun startServer() {
        thread {
            try {
                serverSocket = bluetoothAdapter?.listenUsingRfcommWithServiceRecord(
                    "BluetoothCall", BluetoothProtocol.SERVICE_UUID
                )
                while (isRunning) {
                    try {
                        val socket = serverSocket?.accept()
                        socket?.let { handleIncomingConnection(it) }
                    } catch (e: IOException) {
                        if (isRunning) Log.e("BTService", "Server accept error", e)
                    }
                }
            } catch (e: IOException) {
                Log.e("BTService", "Server socket error", e)
            }
        }
    }

    private fun handleIncomingConnection(socket: BluetoothSocket) {
        val address = socket.remoteDevice.address
        val name = socket.remoteDevice.name ?: "Unknown"
        clientSockets[address] = socket
        outputStreams[address] = socket.outputStream
        inputStreams[address] = socket.inputStream
        connectedDevices.add(address)

        val contact = AppData.getOrCreateContact(socket.remoteDevice)
        contact.isConnected = true

        sendBroadcast(Intent(BluetoothProtocol.ACTION_DEVICE_CONNECTED).apply {
            putExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS, address)
            putExtra(BluetoothProtocol.EXTRA_DEVICE_NAME, name)
        })

        thread { listenForData(address, socket.inputStream) }
    }

    fun connectToDevice(device: BluetoothDevice): Boolean {
        return try {
            val socket = device.createRfcommSocketToServiceRecord(BluetoothProtocol.SERVICE_UUID)
            socket.connect()
            val address = device.address
            clientSockets[address] = socket
            outputStreams[address] = socket.outputStream
            inputStreams[address] = socket.inputStream
            connectedDevices.add(address)

            val contact = AppData.getOrCreateContact(device)
            contact.isConnected = true

            sendBroadcast(Intent(BluetoothProtocol.ACTION_DEVICE_CONNECTED).apply {
                putExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS, address)
                putExtra(BluetoothProtocol.EXTRA_DEVICE_NAME, device.name ?: "Unknown")
            })

            thread { listenForData(address, socket.inputStream) }
            true
        } catch (e: IOException) {
            Log.e("BTService", "Connect error", e)
            false
        }
    }

    private fun listenForData(address: String, inputStream: InputStream) {
        val buffer = ByteArray(1024)
        try {
            while (true) {
                val bytesRead = inputStream.read(buffer)
                if (bytesRead <= 0) break
                processPacket(address, buffer.copyOf(bytesRead))
            }
        } catch (e: IOException) {
            Log.e("BTService", "Listen error for $address", e)
        } finally {
            disconnectDevice(address)
        }
    }

    private fun processPacket(address: String, data: ByteArray) {
        if (data.isEmpty()) return
        val type = data[0].toInt() and 0xFF
        val payload = if (data.size > 1) String(data, 1, data.size - 1) else ""
        val device = clientSockets[address]?.remoteDevice
        val name = device?.name ?: "Unknown"

        when (type) {
            BluetoothProtocol.TYPE_TEXT -> {
                val msg = TextMessage(
                    deviceAddress = address,
                    deviceName = name,
                    text = payload,
                    isSent = false
                )
                AppData.messages.add(msg)
                sendBroadcast(Intent(BluetoothProtocol.ACTION_MESSAGE_RECEIVED).apply {
                    putExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS, address)
                    putExtra(BluetoothProtocol.EXTRA_DEVICE_NAME, name)
                    putExtra(BluetoothProtocol.EXTRA_MESSAGE, payload)
                })
            }
            BluetoothProtocol.TYPE_CALL_START -> {
                if (!isInCall) {
                    sendBroadcast(Intent(BluetoothProtocol.ACTION_INCOMING_CALL).apply {
                        putExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS, address)
                        putExtra(BluetoothProtocol.EXTRA_DEVICE_NAME, name)
                    })
                } else {
                    sendPacket(address, BluetoothProtocol.TYPE_CALL_REJECT, "busy")
                }
            }
            BluetoothProtocol.TYPE_CALL_ACCEPT -> {
                startAudioStreaming()
            }
            BluetoothProtocol.TYPE_CALL_END -> {
                endCallInternal()
            }
            BluetoothProtocol.TYPE_AUDIO_DATA -> {
                if (isInCall && !isMuted) {
                    playAudio(data.copyOfRange(1, data.size))
                }
            }
        }
    }

    private fun sendPacket(address: String, type: Int, data: String) {
        try {
            val os = outputStreams[address] ?: return
            val packet = byteArrayOf(type.toByte()) + data.toByteArray()
            os.write(packet)
            os.flush()
        } catch (e: IOException) {
            Log.e("BTService", "Send error", e)
        }
    }

    private fun sendAudioPacket(address: String, audioData: ByteArray) {
        try {
            val os = outputStreams[address] ?: return
            val packet = byteArrayOf(BluetoothProtocol.TYPE_AUDIO_DATA.toByte()) + audioData
            os.write(packet)
            os.flush()
        } catch (e: IOException) {
            Log.e("BTService", "Audio send error", e)
        }
    }

    fun sendTextMessage(address: String, text: String): Boolean {
        val contact = AppData.contacts.find { it.address == address }
        if (contact?.isConnected != true) {
            val device = bluetoothAdapter?.getRemoteDevice(address)
            if (device != null && !connectToDevice(device)) return false
        }
        sendPacket(address, BluetoothProtocol.TYPE_TEXT, text)
        AppData.messages.add(TextMessage(
            deviceAddress = address,
            deviceName = contact?.name ?: "Unknown",
            text = text,
            isSent = true
        ))
        return true
    }

    fun initiateCall(address: String): Boolean {
        val contact = AppData.contacts.find { it.address == address }
        if (contact?.isConnected != true) {
            val device = bluetoothAdapter?.getRemoteDevice(address)
            if (device != null && !connectToDevice(device)) return false
        }
        isInCall = true
        currentCallDevice = address
        callStartTime = System.currentTimeMillis()
        wakeLock?.acquire(10 * 60 * 1000L)
        sendPacket(address, BluetoothProtocol.TYPE_CALL_START, "")
        return true
    }

    fun acceptCall(address: String) {
        isInCall = true
        currentCallDevice = address
        callStartTime = System.currentTimeMillis()
        wakeLock?.acquire(10 * 60 * 1000L)
        sendPacket(address, BluetoothProtocol.TYPE_CALL_ACCEPT, "")
        startAudioStreaming()
    }

    fun rejectCall(address: String) {
        sendPacket(address, BluetoothProtocol.TYPE_CALL_REJECT, "")
    }

    fun endCall() {
        currentCallDevice?.let { sendPacket(it, BluetoothProtocol.TYPE_CALL_END, "") }
        endCallInternal()
    }

    private fun endCallInternal() {
        if (!isInCall) return
        val duration = if (callStartTime > 0) System.currentTimeMillis() - callStartTime else 0
        currentCallDevice?.let { address ->
            val device = clientSockets[address]?.remoteDevice
            AppData.callLogs.add(CallLogEntry(
                deviceAddress = address,
                deviceName = device?.name ?: "Unknown",
                type = 1,
                duration = duration
            ))
        }
        isInCall = false
        currentCallDevice = null
        callStartTime = 0
        stopAudioStreaming()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        sendBroadcast(Intent(BluetoothProtocol.ACTION_CALL_ENDED))
    }

    private fun startAudioStreaming() {
        // Setup AudioRecord
        val minBuffer = AudioRecord.getMinBufferSize(
            BluetoothProtocol.SAMPLE_RATE,
            BluetoothProtocol.CHANNEL_CONFIG,
            BluetoothProtocol.AUDIO_FORMAT
        )
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            BluetoothProtocol.SAMPLE_RATE,
            BluetoothProtocol.CHANNEL_CONFIG,
            BluetoothProtocol.AUDIO_FORMAT,
            minBuffer.coerceAtLeast(BluetoothProtocol.BUFFER_SIZE * 2)
        )

        // Setup AudioTrack
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(BluetoothProtocol.SAMPLE_RATE)
                    .setEncoding(BluetoothProtocol.AUDIO_FORMAT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuffer.coerceAtLeast(BluetoothProtocol.BUFFER_SIZE * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
        audioRecord?.startRecording()

        // Start recording thread
        thread {
            val buffer = ByteArray(BluetoothProtocol.BUFFER_SIZE)
            while (isInCall && !isMuted) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0 && currentCallDevice != null) {
                    sendAudioPacket(currentCallDevice!!, buffer.copyOf(read))
                }
            }
        }
    }

    private fun playAudio(audioData: ByteArray) {
        try {
            audioTrack?.write(audioData, 0, audioData.size)
        } catch (e: Exception) {
            Log.e("BTService", "Audio play error", e)
        }
    }

    private fun stopAudioStreaming() {
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.e("BTService", "Audio stop error", e)
        }
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
        audioManager?.isMicrophoneMute = muted
    }

    fun isDeviceConnected(address: String): Boolean = connectedDevices.contains(address)
    fun getConnectedDevices(): Set<String> = connectedDevices.toSet()
    fun isInCall(): Boolean = isInCall
    fun getCurrentCallDevice(): String? = currentCallDevice

    private fun disconnectDevice(address: String) {
        connectedDevices.remove(address)
        val contact = AppData.contacts.find { it.address == address }
        contact?.isConnected = false

        try { inputStreams[address]?.close() } catch (_: Exception) {}
        try { outputStreams[address]?.close() } catch (_: Exception) {}
        try { clientSockets[address]?.close() } catch (_: Exception) {}

        inputStreams.remove(address)
        outputStreams.remove(address)
        clientSockets.remove(address)

        if (currentCallDevice == address) {
            endCallInternal()
        }

        sendBroadcast(Intent(BluetoothProtocol.ACTION_DEVICE_DISCONNECTED).apply {
            putExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS, address)
        })
    }

    fun disconnectAll() {
        connectedDevices.toList().forEach { disconnectDevice(it) }
    }

    override fun onDestroy() {
        isRunning = false
        disconnectAll()
        try { serverSocket?.close() } catch (_: Exception) {}
        stopAudioStreaming()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        try { unregisterReceiver(bluetoothReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
