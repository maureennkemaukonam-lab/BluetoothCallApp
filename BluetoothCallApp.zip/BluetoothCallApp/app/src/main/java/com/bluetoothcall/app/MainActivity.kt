package com.bluetoothcall.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {

    private var btService: BluetoothCallService? = null
    private var serviceBound = false
    private lateinit var tabLayout: TabLayout
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var btnScan: Button
    private lateinit var btnEnableBt: Button

    private var currentTab = 0
    private val deviceAdapter = DeviceAdapter()
    private val messageAdapter = MessageContactAdapter()
    private val callLogAdapter = CallLogAdapter()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as BluetoothCallService.LocalBinder
            btService = binder.getService()
            serviceBound = true
            refreshCurrentTab()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            btService = null
            serviceBound = false
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothProtocol.ACTION_DEVICE_CONNECTED,
                BluetoothProtocol.ACTION_DEVICE_DISCONNECTED,
                BluetoothProtocol.ACTION_MESSAGE_RECEIVED,
                BluetoothProtocol.ACTION_CALL_ENDED -> {
                    runOnUiThread { refreshCurrentTab() }
                }
                BluetoothProtocol.ACTION_INCOMING_CALL -> {
                    val address = intent.getStringExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS) ?: return
                    val name = intent.getStringExtra(BluetoothProtocol.EXTRA_DEVICE_NAME) ?: "Unknown"
                    showIncomingCallDialog(address, name)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tabLayout = findViewById(R.id.tabLayout)
        recyclerView = findViewById(R.id.recyclerView)
        emptyView = findViewById(R.id.emptyView)
        btnScan = findViewById(R.id.btnScan)
        btnEnableBt = findViewById(R.id.btnEnableBt)

        recyclerView.layoutManager = LinearLayoutManager(this)

        tabLayout.addTab(tabLayout.newTab().setText("Devices"))
        tabLayout.addTab(tabLayout.newTab().setText("Messages"))
        tabLayout.addTab(tabLayout.newTab().setText("Call Log"))

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentTab = tab?.position ?: 0
                refreshCurrentTab()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        btnScan.setOnClickListener { startDiscovery() }
        btnEnableBt.setOnClickListener { enableBluetooth() }

        checkPermissions()
        bindService()
        registerReceiver()
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.RECORD_AUDIO)
        }
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 100)
        }
    }

    private fun bindService() {
        Intent(this, BluetoothCallService::class.java).also {
            startService(it)
            bindService(it, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothProtocol.ACTION_DEVICE_CONNECTED)
            addAction(BluetoothProtocol.ACTION_DEVICE_DISCONNECTED)
            addAction(BluetoothProtocol.ACTION_MESSAGE_RECEIVED)
            addAction(BluetoothProtocol.ACTION_INCOMING_CALL)
            addAction(BluetoothProtocol.ACTION_CALL_ENDED)
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        registerReceiver(broadcastReceiver, filter)
    }

    private fun refreshCurrentTab() {
        when (currentTab) {
            0 -> showDevicesTab()
            1 -> showMessagesTab()
            2 -> showCallLogTab()
        }
    }

    private fun showDevicesTab() {
        recyclerView.adapter = deviceAdapter
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            emptyView.text = "Bluetooth not supported on this device"
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
            btnScan.visibility = View.GONE
            btnEnableBt.visibility = View.GONE
            return
        }

        if (!adapter.isEnabled) {
            emptyView.text = "Bluetooth is disabled. Tap button to enable."
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
            btnScan.visibility = View.GONE
            btnEnableBt.visibility = View.VISIBLE
            return
        }

        btnEnableBt.visibility = View.GONE
        btnScan.visibility = View.VISIBLE

        val pairedDevices = adapter.bondedDevices?.toList() ?: emptyList()
        for (device in pairedDevices) {
            AppData.getOrCreateContact(device)
        }

        val contacts = AppData.contacts.sortedByDescending { it.isConnected }
        deviceAdapter.setData(contacts)

        if (contacts.isEmpty()) {
            emptyView.text = "No devices found. Tap Scan to discover nearby phones."
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun showMessagesTab() {
        recyclerView.adapter = messageAdapter
        val recentContacts = AppData.messages
            .groupBy { it.deviceAddress }
            .map { (_, msgs) -> msgs.last() }
            .sortedByDescending { it.timestamp }

        messageAdapter.setData(recentContacts)

        if (recentContacts.isEmpty()) {
            emptyView.text = "No messages yet. Start chatting from the Devices tab."
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun showCallLogTab() {
        recyclerView.adapter = callLogAdapter
        val logs = AppData.callLogs.sortedByDescending { it.timestamp }
        callLogAdapter.setData(logs)

        if (logs.isEmpty()) {
            emptyView.text = "No calls yet."
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }

    private fun startDiscovery() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Bluetooth scan permission needed", Toast.LENGTH_SHORT).show()
            return
        }
        if (adapter.isDiscovering) adapter.cancelDiscovery()
        adapter.startDiscovery()
        Toast.makeText(this, "Scanning for devices...", Toast.LENGTH_SHORT).show()
    }

    private fun enableBluetooth() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        if (!adapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        }
    }

    private fun showIncomingCallDialog(address: String, name: String) {
        AlertDialog.Builder(this)
            .setTitle("Incoming Call")
            .setMessage("Call from $name")
            .setCancelable(false)
            .setPositiveButton("Accept") { _, _ ->
                btService?.acceptCall(address)
                startActivity(Intent(this, CallActivity::class.java).apply {
                    putExtra("device_address", address)
                    putExtra("device_name", name)
                    putExtra("is_incoming", true)
                })
            }
            .setNegativeButton("Reject") { _, _ ->
                btService?.rejectCall(address)
            }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            refreshCurrentTab()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCurrentTab()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) unbindService(serviceConnection)
        try { unregisterReceiver(broadcastReceiver) } catch (_: Exception) {}
    }

    // Device Adapter
    inner class DeviceAdapter : RecyclerView.Adapter<DeviceAdapter.ViewHolder>() {
        private var items = listOf<BluetoothContact>()

        fun setData(data: List<BluetoothContact>) {
            items = data
            notifyDataSetChanged()
        }

        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
            val tvName: TextView = v.findViewById(R.id.tvDeviceName)
            val tvAddress: TextView = v.findViewById(R.id.tvDeviceAddress)
            val tvStatus: TextView = v.findViewById(R.id.tvDeviceStatus)
            val btnCall: ImageButton = v.findViewById(R.id.btnCall)
            val btnMessage: ImageButton = v.findViewById(R.id.btnMessage)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_device, parent, false))
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvName.text = item.name
            holder.tvAddress.text = item.address
            holder.tvStatus.text = when {
                item.isConnected -> "Connected"
                item.isPaired -> "Paired"
                else -> "Available"
            }
            holder.tvStatus.setTextColor(when {
                item.isConnected -> ContextCompat.getColor(this@MainActivity, android.R.color.holo_green_dark)
                item.isPaired -> ContextCompat.getColor(this@MainActivity, android.R.color.holo_blue_dark)
                else -> ContextCompat.getColor(this@MainActivity, android.R.color.darker_gray)
            })

            holder.btnCall.setOnClickListener {
                if (btService?.isInCall() == true) {
                    Toast.makeText(this@MainActivity, "Already in a call", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val device = BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(item.address)
                if (device != null) {
                    val success = btService?.initiateCall(item.address) ?: false
                    if (success) {
                        startActivity(Intent(this@MainActivity, CallActivity::class.java).apply {
                            putExtra("device_address", item.address)
                            putExtra("device_name", item.name)
                            putExtra("is_incoming", false)
                        })
                    } else {
                        Toast.makeText(this@MainActivity, "Could not connect", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            holder.btnMessage.setOnClickListener {
                startActivity(Intent(this@MainActivity, ChatActivity::class.java).apply {
                    putExtra("device_address", item.address)
                    putExtra("device_name", item.name)
                })
            }
        }

        override fun getItemCount() = items.size
    }

    // Message Contact Adapter
    inner class MessageContactAdapter : RecyclerView.Adapter<MessageContactAdapter.ViewHolder>() {
        private var items = listOf<TextMessage>()

        fun setData(data: List<TextMessage>) {
            items = data
            notifyDataSetChanged()
        }

        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
            val tvName: TextView = v.findViewById(R.id.tvMsgContactName)
            val tvPreview: TextView = v.findViewById(R.id.tvMsgPreview)
            val tvTime: TextView = v.findViewById(R.id.tvMsgTime)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_message_contact, parent, false))
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvName.text = item.deviceName
            holder.tvPreview.text = item.text
            holder.tvTime.text = formatTime(item.timestamp)
            holder.itemView.setOnClickListener {
                startActivity(Intent(this@MainActivity, ChatActivity::class.java).apply {
                    putExtra("device_address", item.deviceAddress)
                    putExtra("device_name", item.deviceName)
                })
            }
        }

        override fun getItemCount() = items.size
    }

    // Call Log Adapter
    inner class CallLogAdapter : RecyclerView.Adapter<CallLogAdapter.ViewHolder>() {
        private var items = listOf<CallLogEntry>()

        fun setData(data: List<CallLogEntry>) {
            items = data
            notifyDataSetChanged()
        }

        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
            val tvName: TextView = v.findViewById(R.id.tvCallName)
            val tvType: TextView = v.findViewById(R.id.tvCallType)
            val tvTime: TextView = v.findViewById(R.id.tvCallTime)
            val tvDuration: TextView = v.findViewById(R.id.tvCallDuration)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_call_log, parent, false))
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvName.text = item.deviceName
            holder.tvType.text = when (item.type) {
                1 -> "Incoming"
                2 -> "Outgoing"
                else -> "Missed"
            }
            holder.tvTime.text = formatTime(item.timestamp)
            holder.tvDuration.text = if (item.duration > 0) formatDuration(item.duration) else ""
        }

        override fun getItemCount() = items.size
    }

    private fun formatTime(timestamp: Long): String {
        val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        return sdf.format(java.util.Date(timestamp))
    }

    private fun formatDuration(ms: Long): String {
        val sec = ms / 1000
        return String.format("%02d:%02d", sec / 60, sec % 60)
    }
}
