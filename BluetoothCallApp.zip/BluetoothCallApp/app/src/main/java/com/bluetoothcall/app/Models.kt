package com.bluetoothcall.app

import android.bluetooth.BluetoothDevice

data class BluetoothContact(
    val address: String,
    var name: String,
    var isPaired: Boolean = false,
    var isConnected: Boolean = false
)

data class TextMessage(
    val id: Long = System.currentTimeMillis(),
    val deviceAddress: String,
    val deviceName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSent: Boolean
)

data class CallLogEntry(
    val id: Long = System.currentTimeMillis(),
    val deviceAddress: String,
    val deviceName: String,
    val type: Int, // 1 = incoming, 2 = outgoing, 3 = missed
    val timestamp: Long = System.currentTimeMillis(),
    val duration: Long = 0
)

object AppData {
    val contacts = mutableListOf<BluetoothContact>()
    val messages = mutableListOf<TextMessage>()
    val callLogs = mutableListOf<CallLogEntry>()

    fun getMessagesForDevice(address: String): List<TextMessage> {
        return messages.filter { it.deviceAddress == address }.sortedBy { it.timestamp }
    }

    fun getCallLogsForDevice(address: String): List<CallLogEntry> {
        return callLogs.filter { it.deviceAddress == address }.sortedByDescending { it.timestamp }
    }

    fun getOrCreateContact(device: BluetoothDevice): BluetoothContact {
        val existing = contacts.find { it.address == device.address }
        if (existing != null) return existing
        val newContact = BluetoothContact(
            address = device.address,
            name = device.name ?: "Unknown Device",
            isPaired = device.bondState == BluetoothDevice.BOND_BONDED
        )
        contacts.add(newContact)
        return newContact
    }
}
