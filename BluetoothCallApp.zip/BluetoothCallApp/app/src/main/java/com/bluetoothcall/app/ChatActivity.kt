package com.bluetoothcall.app

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    private var btService: BluetoothCallService? = null
    private var serviceBound = false
    private lateinit var recyclerView: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: ImageButton
    private lateinit var tvChatName: TextView
    private lateinit var adapter: MessageAdapter

    private var deviceAddress = ""
    private var deviceName = ""

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as BluetoothCallService.LocalBinder
            btService = binder.getService()
            serviceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            btService = null
            serviceBound = false
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothProtocol.ACTION_MESSAGE_RECEIVED) {
                val addr = intent.getStringExtra(BluetoothProtocol.EXTRA_DEVICE_ADDRESS)
                if (addr == deviceAddress) {
                    refreshMessages()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        deviceAddress = intent.getStringExtra("device_address") ?: ""
        deviceName = intent.getStringExtra("device_name") ?: "Unknown"

        recyclerView = findViewById(R.id.recyclerChat)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        tvChatName = findViewById(R.id.tvChatName)

        tvChatName.text = deviceName
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MessageAdapter(deviceAddress)
        recyclerView.adapter = adapter

        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val success = btService?.sendTextMessage(deviceAddress, text) ?: false
            if (success) {
                etMessage.text.clear()
                refreshMessages()
            } else {
                Toast.makeText(this, "Failed to send. Make sure device is connected.", Toast.LENGTH_SHORT).show()
            }
        }

        bindService()
        registerReceiver(broadcastReceiver, IntentFilter(BluetoothProtocol.ACTION_MESSAGE_RECEIVED))
        refreshMessages()
    }

    private fun bindService() {
        Intent(this, BluetoothCallService::class.java).also {
            bindService(it, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun refreshMessages() {
        val msgs = AppData.getMessagesForDevice(deviceAddress)
        adapter.setData(msgs)
        if (msgs.isNotEmpty()) {
            recyclerView.scrollToPosition(msgs.size - 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshMessages()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) unbindService(serviceConnection)
        try { unregisterReceiver(broadcastReceiver) } catch (_: Exception) {}
    }

    inner class MessageAdapter(private val deviceAddr: String) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {
        private var items = listOf<TextMessage>()

        fun setData(data: List<TextMessage>) {
            items = data
            notifyDataSetChanged()
        }

        inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
            val tvText: TextView = v.findViewById(R.id.tvMessageText)
            val tvTime: TextView = v.findViewById(R.id.tvMessageTime)
        }

        override fun getItemViewType(position: Int): Int {
            return if (items[position].isSent) 1 else 0
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val layout = if (viewType == 1) R.layout.item_message_sent else R.layout.item_message_received
            return ViewHolder(LayoutInflater.from(parent.context).inflate(layout, parent, false))
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvText.text = item.text
            holder.tvTime.text = formatTime(item.timestamp)
        }

        override fun getItemCount() = items.size

        private fun formatTime(timestamp: Long): String {
            val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
            return sdf.format(java.util.Date(timestamp))
        }
    }
}
