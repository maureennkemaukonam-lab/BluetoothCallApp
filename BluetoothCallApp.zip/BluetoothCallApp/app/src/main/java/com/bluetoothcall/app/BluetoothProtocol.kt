package com.bluetoothcall.app

object BluetoothProtocol {
    val SERVICE_UUID = java.util.UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    const val TYPE_TEXT = 0x01
    const val TYPE_CALL_START = 0x02
    const val TYPE_CALL_END = 0x03
    const val TYPE_AUDIO_DATA = 0x04
    const val TYPE_CALL_ACCEPT = 0x05
    const val TYPE_CALL_REJECT = 0x06

    const val ACTION_INCOMING_CALL = "com.bluetoothcall.app.INCOMING_CALL"
    const val ACTION_CALL_ENDED = "com.bluetoothcall.app.CALL_ENDED"
    const val ACTION_MESSAGE_RECEIVED = "com.bluetoothcall.app.MESSAGE_RECEIVED"
    const val ACTION_DEVICE_CONNECTED = "com.bluetoothcall.app.DEVICE_CONNECTED"
    const val ACTION_DEVICE_DISCONNECTED = "com.bluetoothcall.app.DEVICE_DISCONNECTED"

    const val EXTRA_DEVICE_ADDRESS = "device_address"
    const val EXTRA_DEVICE_NAME = "device_name"
    const val EXTRA_MESSAGE = "message"

    // Audio settings
    const val SAMPLE_RATE = 8000
    const val CHANNEL_CONFIG = android.media.AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_FORMAT = android.media.AudioFormat.ENCODING_PCM_16BIT
    const val BUFFER_SIZE = 320 // 20ms at 8kHz, 16-bit mono
}
