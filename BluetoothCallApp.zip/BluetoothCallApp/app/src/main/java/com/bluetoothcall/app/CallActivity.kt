package com.bluetoothcall.app

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class CallActivity : AppCompatActivity() {

    private var btService: BluetoothCallService? = null
    private var serviceBound = false
    private lateinit var tvCallerName: TextView
    private lateinit var tvCallStatus: TextView
    private lateinit var tvCallTimer: TextView
    private lateinit var btnMute: ImageButton
    private lateinit var btnSpeaker: ImageButton
    private lateinit var btnEndCall: ImageButton

    private var deviceAddress = ""
    private var deviceName = ""
    private var isIncoming = false
    private var isMuted = false
    private var isSpeakerOn = false
    private var timerRunning = false
    private var startTime = 0L

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as BluetoothCallService.LocalBinder
            btService = binder.getService()
            serviceBound = true
            updateUI()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            btService = null
            serviceBound = false
        }
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothProtocol.ACTION_CALL_ENDED) {
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        deviceAddress = intent.getStringExtra("device_address") ?: ""
        deviceName = intent.getStringExtra("device_name") ?: "Unknown"
        isIncoming = intent.getBooleanExtra("is_incoming", false)

        tvCallerName = findViewById(R.id.tvCallerName)
        tvCallStatus = findViewById(R.id.tvCallStatus)
        tvCallTimer = findViewById(R.id.tvCallTimer)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnEndCall = findViewById(R.id.btnEndCall)

        tvCallerName.text = deviceName
        tvCallStatus.text = if (isIncoming) "Connected" else "Calling..."
        tvCallTimer.text = "00:00"

        btnMute.setOnClickListener {
            isMuted = !isMuted
            btService?.setMuted(isMuted)
            btnMute.setColorFilter(ContextCompat.getColor(this, if (isMuted) android.R.color.holo_red_dark else android.R.color.white))
        }

        btnSpeaker.setOnClickListener {
            isSpeakerOn = !isSpeakerOn
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            audioManager.isSpeakerphoneOn = isSpeakerOn
            btnSpeaker.setColorFilter(ContextCompat.getColor(this, if (isSpeakerOn) android.R.color.holo_green_dark else android.R.color.white))
        }

        btnEndCall.setOnClickListener {
            btService?.endCall()
            finish()
        }

        bindService()
        registerReceiver(broadcastReceiver, IntentFilter(BluetoothProtocol.ACTION_CALL_ENDED))

        if (!isIncoming) {
            startTimer()
        } else {
            startTimer()
        }
    }

    private fun bindService() {
        Intent(this, BluetoothCallService::class.java).also {
            bindService(it, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun updateUI() {
        if (btService?.isInCall() == true) {
            tvCallStatus.text = "Connected"
        }
    }

    private fun startTimer() {
        timerRunning = true
        startTime = System.currentTimeMillis()
        android.os.Handler(mainLooper).post(object : Runnable {
            override fun run() {
                if (!timerRunning) return
                val elapsed = System.currentTimeMillis() - startTime
                val sec = elapsed / 1000
                tvCallTimer.text = String.format("%02d:%02d", sec / 60, sec % 60)
                android.os.Handler(mainLooper).postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        timerRunning = false
        if (serviceBound) unbindService(serviceConnection)
        try { unregisterReceiver(broadcastReceiver) } catch (_: Exception) {}
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.isSpeakerphoneOn = false
    }
}
